<?php

class Documento extends Eloquent
{
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'documento';
	
	public function diplomados()
	{
		return $this->hasMany('Diplomado');
	}
	
	public function solicitud()
	{
		return $this->belongsTo('Solicitud','idSolicitud');
	}
	
	
	public function categoria()
	{
		return $this->belongsTo('Categoria','idCategoria');
	}
	
	
	public function licenciaturas()
	{
		return $this->hasMany('Licenciatura');
	}
	
	
}

?>
