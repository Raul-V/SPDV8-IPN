<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFkSeccionSuperacionAcademicaTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//
		
		
		Schema::table('licenciatura', function($table)
		{
			$table->foreign('id')->references('id')->on('documento');		
		}
		);
		
		Schema::table('diplomado', function($table)
		{
			$table->foreign('id')->references('id')->on('documento');		
		}
		);
		
		Schema::table('idioma', function($table)
		{
			$table->foreign('id')->references('id')->on('documento');		
		}
		);
		
		Schema::table('cursos_proposito_especifico', function($table)
		{
			$table->foreign('id')->references('id')->on('documento');		
		}
		);
		
		Schema::table('estudios_posgrado', function($table)
		{
			$table->foreign('id')->references('id')->on('documento');		
		}
		);
		
		Schema::table('cursos_seminarios_talleres', function($table)
		{
			$table->foreign('id')->references('id')->on('documento');		
		}
		);
		
		
		Schema::table('programas_proyectos_areas_centrales', function($table)
		{
			$table->foreign('id')->references('id')->on('documento');		
		}
		);
		
		Schema::table('comision_evaluacion', function($table)
		{
			$table->foreign('id')->references('id')->on('documento');		
		}
		);		
		
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		//
		
		
	}

}
