<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInfoProcesoTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//
		Schema::create('info_proceso', function($table)
		{
			$table->increments('id');
			$table->timestamp('fechaInicioRegistro');
			$table->timestamp('fechaFinRegistro');
			$table->timestamp('fechaInicioCompulsa');
			$table->timestamp('fechaFinCompulsa');
			$table->timestamp('fechaInicioComiteInterno');
			$table->timestamp('fechaFinComiteInterno');
			$table->timestamp('fechaInicioComiteExterno');
			$table->timestamp('fechaFinComiteExterno');
			$table->timestamp('fechaInicioApelacion');
			$table->timestamp('fechaFinApelacion');
			
			$table->timestamps();
		}
		);
		
		
		
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		//
		Schema::drop('info_proceso');
	}

}
