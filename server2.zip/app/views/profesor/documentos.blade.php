<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Mis Documentos ({{Auth::user()->nombre}})</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="../stylesheet" href="css/login.css">
    <link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">
	<script src="//code.jquery.com/jquery.js"></script>
    
    <script src="js/bootstrap.min.js"></script>
  <style type="text/css">
    button{
      float:right;
      margin-right: 10px;
    }
  </style>

	<!--<link rel="stylesheet" type="text/css" href="css/estilo.css">-->
</head>
<body>
<!--Se incluye el encabezado de la pagina y la imagen de la pagina -->
<img src="../imagenes/bannerIPN.png">

<!--Se hace la parte del menu -->
	<nav class="navbar navbar-default" role="navigation">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Menú</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li><a href="#"><span class="glyphicon glyphicon-home"></span> Inicio</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Mi Perfil</a></li>      
        <li class= "active"><a href="#"><span class="glyphicon glyphicon-folder-close"></span> Mis documentos</a></li>
      </ul>
      <!--
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Número de Empleado">
        </div>
        <button type="submit" class="btn btn-default">Buscar</button>
      </form>-->
      <ul class="nav navbar-nav navbar-right">
       <li><a href="#">Ayuda</a></li>
       <li><a href="../logout">Cerrar Sesión</a></li>
       <p class="navbar-text navbar-right">Mi nombre es:<a href="#" class="bg-success"> {{Auth::user()->nombre}} </a></p>
      </ul>
    </div><!-- /.navbar-collapse -->
   


      <div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
          Docencia
        </a>
      </h4>
    </div>
    <div id="collapseOne" class="panel-collapse collapse in">
      <div class="panel-body">
                       <ul class="list-group">
                        <li class="list-group-item">Carga Académica <button type="button" class="btn btn-danger">Eliminar</button> <button type="button" class="btn btn-info">Modificar</button></li>
                        <li class="list-group-item">Instructor de programas de formación docente, actualización profesional <button type="button" class="btn btn-danger">Eliminar</button> <button type="button" class="btn btn-info">Modificar</button></li>
                        <li class="list-group-item">Cursos de recuperación académica, curriculares de regularización <button type="button" class="btn btn-danger">Eliminar</button> <button type="button" class="btn btn-info">Modificar</button></li>
                        <li class="list-group-item">Programa institucional de orientación juvenil <button type="button" class="btn btn-danger">Eliminar</button> <button type="button" class="btn btn-info">Modificar</button></li>
                        <li class="list-group-item">programa de inducción, propedéutico o atención a pasantes de NMS, S y Posgrado <button type="button" class="btn btn-danger">Eliminar</button> <button type="button" class="btn btn-info">Modificar</button></li>
                      </ul>
                        
                      
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
          Investigación
        </a>
      </h4>
    </div>
    <div id="collapseTwo" class="panel-collapse collapse">
      <div class="panel-body">
       ...
      </div>
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
          Superación académica
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse">
      <div class="panel-body">
        ..
      </div>
    </div>
  </div>

    <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
          Actividades complementarias y de apoyo a la docencia y a la investigación.
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse">
      <div class="panel-body">
        ..
      </div>
    </div>
  </div>

<div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
         Actividades de extensión, integración y difusión de la ciencia y de la cultura.
        </a>
      </h4>
    </div>
    <div id="collapseThree" class="panel-collapse collapse">
      <div class="panel-body">
        ..
      </div>
    </div>
  </div>



</div>



    

    

      </div><!-- /.container-fluid -->
    </nav>		
<!-- -->
    


</body>
</html>