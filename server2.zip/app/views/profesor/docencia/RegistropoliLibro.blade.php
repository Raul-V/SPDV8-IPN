@extends('layout.registroDocumentos')

@section('titulo')
  Registrar Polilibro
@stop

@section('nombreUsuario')
  {{Auth::user()->nombre}} <!--No cambiar esta seccion -->
@stop

@section('tituloForm')
  Registrar Polilibro
@stop

@section('formulario')
    

            <div class="row">
              <div class="col-md-2"> </div>
              <div class="col-md-8">


                <div class="form-group">
                  <label class="col-md-3 control-label" for="numero">Número de Autores</label>  
                  <div class="col-md-9">
                    <input id="numero" name="numero" placeholder="Ingresa el número de autores" class="form-control input-md" type="text">
                    
                  </div>
                </div>    


              </div>
              <div class="col-md-2"> </div>
            </div>




            <br /><br />


          


            <div class="row">
              <div class="col-md-2"> </div>
              <div class="col-md-8">


                <div class="form-group">
                  <label class="col-md-3 control-label" for="aplicacion">Nivel de Aplicación</label>
                  <div class="col-md-9">
                    <input id="aplicacion" name="aplicacion" class="form-control input-md" type="text">
                  </div>
                </div>


              </div>
              <div class="col-md-2"> </div>
            </div>




            <br /><br />



            <div class="row">
              <div class="row">
                <div class="col-md-5 col-md-offset-5">
                  <h3>Edición</h3>
                </div>
              </div>


            <br /><br />
              <div class="col-md-2"> </div>

              <div class="col-md-4"> 

                <div class="form-group">
                  <label class="col-md-3 control-label" for="año">Año</label>  
                  <div class="col-md-9">
                    <input id="año" name="año" placeholder="20XX" class="form-control input-md" type="text">                    
                  </div>
                </div> 


              </div>
              
              <div class="col-md-4">

                <div class="form-group">
                  <label class="col-md-3 control-label" for="Pais">País</label>  
                  <div class="col-md-9">
                    <input id="pais" name="pais" placeholder="Nombre del país" class="form-control input-md" type="text">                    
                  </div>
                </div> 

              </div>

              <div class="col-md-2"> </div>
              
            </div>

            


            <br /><br />
            




            <div class="row">
              <div class="row">
                <div class="col-md-5 col-md-offset-5">
                  <h3>Constancia de Validación</h3>
                </div>
              </div>
              <br />
            <br />

              <div class="col-md-4"> 

                <div class="form-group">
                  <label class="col-md-3 control-label" for="Constancianumero">No.</label>  
                  <div class="col-md-9">
                    <input id="Constancianumero" name="Constancianumero" placeholder="Ingresa la fecha de inicio" class="form-control input-md" type="text">                    
                  </div>
                </div> 


              </div>
              
              <div class="col-md-4">

                <div class="form-group">
                  <label class="col-md-3 control-label" for="fecha">Fecha</label>  
                  <div class="col-md-9">
                    <input id="fecha" name="fecha" placeholder="Ingresa la fecha de tuconstancia" class="form-control input-md" type="date">                    
                  </div>
                </div> 

              </div>

              <div class="col-md-4"> 

                <div class="form-group">
                  <label class="col-md-3 control-label" for="calidad">Calidad</label>  
                  <div class="col-md-9">
                   <select multiple class="form-control" name="calidad" id="calidad">
                      <option>Regular = 20 UP</option>
                      <option>Buena = 50 UP</option>
                      <option>Excelente = 80 UP</option>
                      
                    </select>                   
                  </div>
                </div> 


              </div>

             
              
            </div>


            <br /><br />

            <br /><br />

<div class="row">
  <div class="col-md-4"></div>
  <div class="col-md-4">
    <div class="form-group">
      
          <label class="col-md-3 control-label" for="constancia">Documento</label>
                  <div class="col-md-4">
                    <input id="constancia" name="constancia"  type="file">
                  </div>
                </div>
      </div>
  <div class="col-md-4"></div>
</div>

                 
 <br /><br />
  <br />

            <div class="row">
              <div class="col-md-2"> </div>
              <div class="col-md-8">


                <div class="form-group">                

                  <label class="col-md-4 control-label" for="registrar"></label>
                  <div class="col-md-8">
                    <button id="registrar" name="registrar" class="btn btn-primary">Registrar</button>
                    <button id="cancelar" name="cancelar" class="btn btn-danger">Cancelar</button>
                  </div>

                </div>  


              </div>
              <div class="col-md-2"> </div>
            </div>
@stop







