<!doctype html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>@yield('titulo')</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">    
	{{HTML::style('css/bootstrap.min.css')}}
	{{ HTML::script('js/bootstrap.min.js') }}          
</head>
<body>
<!--Banner de la página-->
{{HTML::image('imagenes/bannerIPN.png')}}

@section('navbar')
<!--Se hace la parte del menu -->	
	<nav class="navbar navbar-default" role="navigation">
		<div class="container-fluid">    <!-- Brand and toggle get grouped for better mobile display -->
			<div class="navbar-header">
			  <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			  </button>
			  <!--Barra de navegacion de la derecha-->
			  <ul class="nav navbar-nav navbar-right">
			   <li><a href="#">Ayuda</a></li>
			   <li><a href="{{action('LogoutController@getLogout')}}">Cerrar Sesión</a></li>
			   <p class="navbar-text navbar-right">Mi nombre es:<a href="#" class="bg-success"> {{Auth::user()->nombre}} </a></p>
			  </ul>
			</div>

		</div><!-- /.container-fluid -->
</nav>    
@show
<!-- -->
    <br />
    <br />
	
	<!--Aqui va el contenido de la página-->
    <div class="container">      
		@yield('contenido')		
    </div>
    

    

  

    


</body>
</html>
