<?php

class Profesor_RegistrarController extends BaseController
{

	public function __construct()
	{
		
		$this->beforeFilter('auth',array('except' =>array('getLogin','postLogin')));
	}



	public function getIndex()
	{
		return View::make('profesor.registrar');
	}

	public function getDiplomado()
	{
		return View::make('profesor.superacionAcademica.registrarDiplomado');
	}
	
	
	
	
	
	public function postDiplomado()
	{
		$rules=array(
			'nombre' => 'required|min:5',
			'nombreInstitucion' => 'required|min:5',
			'noHoras' => 'required|integer',
			'fechaInicio' => 'required|date|before:'.date('d-m-Y').'|before:'.Input::get('fechaTermino'),
			'fechaTermino' => 'required|date|before:'.date('d-m-Y'),
			'nivel' => 'required',
			'noConstancia' => 'required',
			'fechaConstancia' => 'required|date|before:'.date('d-m-Y'),
			'constanciaFile'=> 'required|image|mimes:jpeg|max:716800'
		
		);
		
		/*Mensajes de error*/		
		$messages=array(
		'nombre.min'=>'El nombre del diplomado que has ingresado es muy corto.',
		'nombreInstitucion.min'=>'El nombre de la institución  que has ingresado es muy corto.',
		'noHoras.integer'=>'El número de horas debe ser un numero entero.',
		'fechaInicio.date'=>'El formato del campo no es válido. Formato esperado (DD-MM-AAA).',
		'fechaInicio.before'=>'La fecha de inicio debe ser anterior a la fecha actual y a la fecha de termino.',
		'fechaTermino.date'=>'El formato del campo no es válido. Formato esperado (DD-MM-AAA).',
		'fechaConstancia.date'=>'El formato del campo no es válido. Formato esperado (DD-MM-AAA).',
		'fechaConstancia.before'=>'La fecha de la constancia debe ser antes de la fecha actual :date.',
		'constanciaFile.image'=> 'La imagen de la constancia debe ser un formato de imagen valido(jpeg)',
		'constanciaFile.mimes'=> 'La imagen de la constancia debe ser un formato de imagen valido(jpeg)',
		'constanciaFile.max'=> 'El tamaño de la imagen de la constancia debe ser menor que 700 KB',
		);
		
		
		$validacion=Validator::make(Input::all(),$rules,$messages);
		/*Validación de los campos del formulario*/
		if($validacion->fails())
		{			
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		
		
		
		
		
		
		
		
		
		$ultimaPromocion=Auth::user()->fechaUltimaPromocion;
		
		if(!$ultimaPromocion)
		{
			//Si nunca se ha promocionado en el sistema. Para efectos de validación damos una fecha arbitraria antigua.
			$ultimaPromocion='31-01-1990';
		}
		
		$rules=array(
			'fechaConstancia' => 'after:'.$ultimaPromocion
		);
		$messages = array(
				'after' => 'La fecha de la constancia debe ser posterior a la fecha de tu última promoción academica ('.$ultimaPromocion.').',
			);
		$validacion=Validator::make(Input::all(),$rules,$messages);
		
		
		/*Validamos que el documento sea de una fecha posterior a su ultima promoción*/		
		if($validacion->fails())
		{			
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		
		
		
		
		
		
		
		
		
		
		
		/*El documento es de una fecha posterior a la ultima promoción, ahora verificar que la diferencia entre la fecha de
		el documento y la fecha actual sea maxima de 4 años
		*/				
		
		$rules=array(
			'fechaConstancia' => 'after:'.date('d-m-Y',strtotime('-4 year'))
		);
		$messages = array(
			'after' => 'La fecha de la constancia no debe ser exceder de 4 años de antiguedad.',
		);
		
		$validacion=Validator::make(Input::all(),$rules,$messages);
		/*Validamos que el documento no tenga antiguedad mayor a 4 años*/
		if($validacion->fails())
		{			
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		
		
		
		
		
		
		
		
		/*Se procede a validar que la fecha de la constancia sea mayor que la fecha de termino del diplomado.
		*/				
		
		$rules=array(
			'fechaConstancia' => 'after:'.Input::get('fechaTermino')
		);
		$messages = array(
			'after' => 'La fecha de la constancia debe ser posterior a la fecha de termino del diplomado.',
		);
		
		$validacion=Validator::make(Input::all(),$rules,$messages);
		/*Validamos que el documento no tenga antiguedad mayor a 4 años*/
		if($validacion->fails())
		{			
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		
		
		
		
		
		
		
		
		
		
		/*Se procede a guardar la información en la base de datos*/
		
		$documento=new Documento;
		
		//Obtenemos las solicitudes activas en periodo de registro que no han sido enviadas (SOLO SE DEBE OBTENER UNA)
		$solicitud=Profesor::find(Auth::user()->id)->solicitudes()->where('estatus','=',0)->get();
		//echo $solicitud.'\n';
		//echo $solicitud->first()->id;
		$solicitud=$solicitud->first();
		$documento->idSolicitud=$solicitud->id;
		
		$categoria=Categoria::where('nombre','=','Superación Académica')->first();
		$documento->idCategoria=$categoria->id;
		
		
		
		$documento->puntos=floor((40*Input::get('noHoras'))/180);
		$documento->noConstancia=Input::get('noConstancia');
		$documento->aprobado=false;
		$documento->cotejado=false;
		$documento->imagenConstancia=Str::random(20).Input::file('constanciaFile')->getClientOriginalName();
		$documento->observacion='';
		$documento->save();
		
		
		$diplomado=new Diplomado;
		$diplomado->documento()->associate($documento);
		$diplomado->nombreDiplomado=Input::get('nombre');
		$diplomado->nombreInstitucion=Input::get('nombreInstitucion');
		$diplomado->noHoras=Input::get('noHoras');
		$diplomado->nivel=Input::get('nivel');
		$diplomado->periodoInicio=Input::get('fechaInicio');
		$diplomado->periodoTermino=Input::get('fechaTermino');
		Input::file('constanciaFile')->move('spdImg',$documento->imagenConstancia);
		$diplomado->save();
		
		
		return Redirect::to('profesor/registrar');		
	}
	
	
	public function getLicenciatura()
	{
		return View::make('profesor.superacionAcademica.registrarLicenciatura');		
	}
	
	public function postLicenciatura()
	{
		
		
		$rules=array(
			'nombre' => 'required|min:5',			
			'fechaExamen' => 'required|date|before:'.date('d-m-Y').'|before:'.Input::get('fechaConstancia'),						
			'noConstancia' => 'required',
			'fechaConstancia' => 'required|date|before:'.date('d-m-Y'),
			'constanciaFile'=> 'required'
			
		);
		
		
		
		
		
		/*Mensajes de error*/		
		$messages=array(
		'nombre.min'=>'El nombre del diplomado que has ingresado es muy corto.',
		'nombreInstitucion.min'=>'El nombre de la institución  que has ingresado es muy corto.',
		'noHoras.integer'=>'El número debe ser un numero entero.',
		'fechaExamen.date'=>'El formato del campo no es válido. Formato esperado (DD-MM-AAA).',
		'fechaExamen.before'=>'La fecha del examen debe ser anterior a la fecha actual y a la fecha de la constancia.',		
		'fechaConstancia.date'=>'El formato del campo no es válido. Formato esperado (DD-MM-AAA).',
		'fechaConstancia.before'=>'La fecha de la constancia debe ser antes de la fecha actual :date.',
		'constanciaFile.image'=> 'La imagen de la constancia debe ser un formato de imagen valido(jpeg)',
		'constanciaFile.mimes'=> 'La imagen de la constancia debe ser un formato de imagen valido(jpeg)',
		'constanciaFile.max'=> 'El tamaño de la imagen de la constancia debe ser menor que 700 KB',
		);
		
		
		
		
		
		
		
		$validacion=Validator::make(Input::all(),$rules,$messages);
		/*Validacion del formulario.*/
		if($validacion->fails())
		{			
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		
		
		
		
		/*Validacion de documentos posteriores a la ultima promocion*/
		$ultimaPromocion=Auth::user()->fechaUltimaPromocion;
		if(!$ultimaPromocion)
		{
			//Si nunca se ha promocionado en el sistema. Para efectos de validación damos una fecha arbitraria antigua.
			$ultimaPromocion='31-01-1990';
		}
		
		$rules=array(
			'fechaConstancia' => 'after:'.$ultimaPromocion
		);
		$messages = array(
				'after' => 'La fecha de la constancia debe ser posterior a la fecha de tu última promoción academica ('.$ultimaPromocion.').',
			);
		$validacion=Validator::make(Input::all(),$rules,$messages);
		/*Validamos que el documento sea de una fecha posterior a su ultima promoción*/
		if($validacion->fails())
		{			
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		
		
		
		
		
		
		
		
		
		/*El documento es de una fecha posterior a la ultima promoción, ahora verificar que la diferencia entre
		el documento y la fecha actual sea maxima de 4 años
		*/				
		
		$rules=array(
			'fechaConstancia' => 'after:'.date('d-m-Y',strtotime('-4 year'))
		);
		$messages = array(
			'after' => 'La fecha de la constancia no debe ser exceder de 4 años de antiguedad.',
		);
		
		$validacion=Validator::make(Input::all(),$rules,$messages);
		/*Validamos que el documento no tenga antiguedad mayor a 4 años*/
		if($validacion->fails())
		{			
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		
		
		
		
		
		
		$documento=new Documento;
		/*Ubicamos la solicitud activa(Solicitud que esta en periodo de registro y no ha sido enviada estatus=0)*/
		$solicitud=Profesor::find(Auth::user()->id)->solicitudes()->where('estatus','=',0)->get();
		
		$solicitud=$solicitud->first();
		$documento->idSolicitud=$solicitud->id;
		
		$categoria=Categoria::where('nombre','=','Superación Académica')->first();
		$documento->idCategoria=$categoria->id;
		
		
		$documento->puntos=60;
		$documento->noConstancia=Input::get('noConstancia');
		$documento->aprobado=false;
		$documento->cotejado=false;
		$documento->imagenConstancia=Str::random(20).Input::file('constanciaFile')->getClientOriginalName();
		$documento->observacion='';
		$documento->save();
		
		$licenciatura=new Licenciatura;
		$licenciatura->documento()->associate($documento);
		$licenciatura->nombre=Input::get('nombre');
		$licenciatura->fechaExamen=Input::get('fechaExamen');
		
		
		Input::file('constanciaFile')->move('spdImg',$documento->imagenConstancia);
		$licenciatura->save();
				
		return Redirect::to('profesor/registrar');
		
	}
}

?>