<?php

	class AuthController extends BaseController
	{
		/*
		**	Se trata la peticion GET<?php

use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableInterface;

class User extends Eloquent implements UserInterface, RemindableInterface 
{
}

?> de /login
		*/
		
		
		public function getIndex()
		{
			return View::make('login');
		}
		
		public function getRegistro()
		{
			$instituciones=Institucion::all();
			return View::make('registro')->with('instituciones',$instituciones);
		}
		
		public function postRegistro()
		{
			$rules=array(
			'noEmpleado'=> 'required|unique:usuario,id|regex:([0-9]{6})',
			'email'=>'required|unique:usuario|email',
			'password'=>'required|min:4',
			'nombre'=>'required|min:3',
			'apellidoP'=>'required|min:3',
			'apellidoM'=>'required|min:3',
			'calle'=>'required|min:3',
			'colonia'=>'required|min:3',
			'numero'=>'required|integer',
			'entidad'=>'required|min:3',
			'ciudad'=>'required|min:3',
			'codigoPostal'=>'required:regex:([0-9]{5})'
			);
		
			$validacion=Validator::make(Input::all(),$rules);			
			if($validacion->fails())
			{
				/*$errores=$validacion->messages();
				foreach($errores->all() as $error)
				{
					$cadena=$cadena.'El error: '.$error;
				}
				return $cadena.Input::get('nombre').Input::get('password');*/
				return Redirect::back()->withErrors($validacion)->withInput();
			}
			
			$user=new User;
			$direccion=new Direccion;
			$institucion=Institucion::where('nombre','=',Input::get('institucion'))->get();
			
			$direccion->calle=Input::get('calle');
			$direccion->colonia=Input::get('colonia');
			$direccion->numero=Input::get('numero');
			$direccion->entidadFederativa=Input::get('entidad');
			$direccion->ciudad=Input::get('ciudad');
			$direccion->codigoPostal=Input::get('codigoPostal');
			$direccion->save();
			
			
			$user->id=Input::get('noEmpleado');
			$user->nombre=Input::get('nombre');
			$user->apellidoP=Input::get('apellidoP');
			$user->apellidoM=Input::get('apellidoM');			
			$user->email=Input::get('email');
			$user->password=Input::get('password');
			$user->rol=0;//Rol para profesor
			
			$user->direccion()->associate($direccion);
			$user->idInstitucion=$institucion->first()->id;			
			
			$user->save();
			
			
			$profesor=new Profesor;
			
			$profesor->id=Input::get('noEmpleado');
			$profesor->categoria=1;
			
			$profesor->save();
			Mail::queue('emailTemplate',Input::all(),function($message) use($user)
			{
				$message->to($user->email,$user->name.$user->apellidoP)->subject('Bienvenido al Sistema de Promocion Docente del IPN');
			}
			);
			return Redirect::to('login');
			
		}
		
		
		/*
		**	Se trata la peticion POST de /login
		*/
		public function postIndex()
		{
			 //Obtener los datos del formularo login
			$credentials= array(
			'id'=>Input::get('noEmpleado'),
			'password'=>Input::get('password'),
			);
			if(Auth::attempt($credentials))
			{
				//El usuario se ha identificado correctamente.
				
				//Redirigir a su pagina inicial cuando el rol es 0, es decir el usuario es un profesor
				if(Auth::user()->rol==0)
				{
					return Redirect::to('profesor');
				}
				
			}
			
			
			else
			{
				//El usuario ha fallado la identifiación
				return Redirect::back()->withInput();
			}
			return View::make('login');
		}
		
		
		
	}

?>