<?php

class Documento extends Eloquent
{
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'documento';
	
	public function diplomados()
	{
		return $this->hasMany('Diplomado');
	}
	
	
	public function licenciaturas()
	{
		return $this->hasMany('Licenciatura');
	}
	
	
}

?>
