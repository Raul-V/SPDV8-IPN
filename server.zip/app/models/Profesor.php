<?php


class Profesor extends Eloquent
{
	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'profesor';
	
	
	
	
	public function plazas()
	{
		$this->hasMany('Plaza','idProfesor');
	}
	
}

?>