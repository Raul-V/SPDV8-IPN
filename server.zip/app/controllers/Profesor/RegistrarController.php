<?php

class Profesor_RegistrarController extends BaseController
{

	public function __construct()
	{
		
		$this->beforeFilter('auth',array('except' =>array('getLogin','postLogin')));
	}



	public function getIndex()
	{
		return View::make('profesor.registrar');
	}

	public function getDiplomado()
	{
		return View::make('profesor.superacionAcademica.registrarDiplomado');
	}
	
	
	
	
	
	public function postDiplomado()
	{
		$rules=array(
			'nombre' => 'required|min:5',
			'nombreInstitucion' => 'required|min:5',
			'noHoras' => 'required|integer',
			'fechaInicio' => 'required|date|before:'.date('d-m-Y').'|before:'.Input::get('fechaTermino'),
			'fechaTermino' => 'required|date|before:'.date('d-m-Y'),
			'nivel' => 'required',
			'noConstancia' => 'required',
			'fechaConstancia' => 'required|date|before:'.date('d-m-Y'),
			'constanciaFile'=> 'required'
		
		);
		
		
		$validacion=Validator::make(Input::all(),$rules);
		
		if($validacion->fails())
		{			
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		else
		{
			$ultimaPromocion=Auth::user()->fechaUltimaPromocion;
			if(!$ultimaPromocion)
			{
				//Si nunca se ha promocionado en el sistema. Para efectos de validación damos una fecha arbitraria antigua.
				$ultimaPromocion='31-01-1990';
			}
			
			$rules=array(
				'fechaConstancia' => 'after:'.$ultimaPromocion
			);
			$messages = array(
					'after' => 'La fecha de la constancia debe ser posterior a la fecha de tu última promoción academica ('.$ultimaPromocion.').',
				);
			$validacion=Validator::make(Input::all(),$rules,$messages);
			/*Validamos que el documento sea de una fecha posterior a su ultima promoción*/
			if($validacion->fails())
			{			
				return Redirect::back()->withErrors($validacion)->withInput();
			}
			else
			{
				/*El documento es de una fecha posterior a la ultima promoción, ahora verificar que la diferencia entre
				el documento y la fecha actual sea maxima de 4 años
				*/				
				
				$rules=array(
					'fechaConstancia' => 'after:'.date('d-m-Y',strtotime('-4 year'))
				);
				$messages = array(
					'after' => 'La fecha de la constancia no debe ser exceder de 4 años de antiguedad.',
				);
				
				$validacion=Validator::make(Input::all(),$rules,$messages);
				/*Validamos que el documento no tenga antiguedad mayor a 4 años*/
				if($validacion->fails())
				{			
					return Redirect::back()->withErrors($validacion)->withInput();
				}
				
				
			}
			
		}
		
		
		$documento=new Documento;
		
		
		$var=Solicitud::where('idProfesor', '=', Auth::user()->id.'')->where('estatus','=','0')->get();
		//echo Solicitud::where('idProfesor', '=', Auth::user()->id.'')->where('estatus','=','0')->toSql().'  '.Auth::user()->id;
		foreach ($var as $d)
		{
			$documento->idSolicitud=$d->id;			
		}
		$var=Categoria::where('nombre','=','Superación Académica')->get();
		foreach ($var as $d)
		{
			$documento->idCategoria=$d->id;	
		}
		$documento->puntos=floor((40*Input::get('noHoras'))/180);
		$documento->noConstancia=Input::get('noConstancia');
		$documento->aprobado=false;
		$documento->cotejado=false;
		$documento->imagenConstancia=Str::random(20).Input::file('constanciaFile')->getClientOriginalName();
		$documento->observacion='';
		$documento->save();
		
		$diplomado=new Diplomado;
		$diplomado->id=$documento->id;
		$diplomado->nombreDiplomado=Input::get('nombre');
		$diplomado->nombreInstitucion=Input::get('nombreInstitucion');
		$diplomado->noHoras=Input::get('noHoras');
		$diplomado->nivel=Input::get('nivel');
		$diplomado->periodoInicio=Input::get('fechaInicio');
		$diplomado->periodoTermino=Input::get('fechaTermino');
		Input::file('constanciaFile')->move('spdImg',$documento->imagenConstancia);
		$diplomado->save();
		
		
		
		
		
		return Redirect::to('profesor/registrar');
		
	}
	
	
	public function getLicenciatura()
	{
		return View::make('profesor.superacionAcademica.registrarLicenciatura');		
	}
	
	public function postLicenciatura()
	{
		
		
		$rules=array(
			'nombre' => 'required|min:5',			
			'fechaExamen' => 'required|date|before:'.date('d-m-Y'),//.'|before:'.Input::get('fechaConstancia'),						
			'noConstancia' => 'required',
			'fechaConstancia' => 'required|date|before:'.date('d-m-Y'),
			'constanciaFile'=> 'required'
			
		);
		
		
		$validacion=Validator::make(Input::all(),$rules);
		
		if($validacion->fails())
		{			
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		else
		{
			$ultimaPromocion=Auth::user()->fechaUltimaPromocion;
			if(!$ultimaPromocion)
			{
				//Si nunca se ha promocionado en el sistema. Para efectos de validación damos una fecha arbitraria antigua.
				$ultimaPromocion='31-01-1990';
			}
			
			$rules=array(
				'fechaConstancia' => 'after:'.$ultimaPromocion
			);
			$messages = array(
					'after' => 'La fecha de la constancia debe ser posterior a la fecha de tu última promoción academica ('.$ultimaPromocion.').',
				);
			$validacion=Validator::make(Input::all(),$rules,$messages);
			/*Validamos que el documento sea de una fecha posterior a su ultima promoción*/
			if($validacion->fails())
			{			
				return Redirect::back()->withErrors($validacion)->withInput();
			}
			else
			{
				/*El documento es de una fecha posterior a la ultima promoción, ahora verificar que la diferencia entre
				el documento y la fecha actual sea maxima de 4 años
				*/				
				
				$rules=array(
					'fechaConstancia' => 'after:'.date('d-m-Y',strtotime('-4 year'))
				);
				$messages = array(
					'after' => 'La fecha de la constancia no debe ser exceder de 4 años de antiguedad.',
				);
				
				$validacion=Validator::make(Input::all(),$rules,$messages);
				/*Validamos que el documento no tenga antiguedad mayor a 4 años*/
				if($validacion->fails())
				{			
					return Redirect::back()->withErrors($validacion)->withInput();
				}
				
				
			}
			
		}
		
		
		$documento=new Documento;
		
		
		$var=Solicitud::where('idProfesor', '=', Auth::user()->id.'')->where('estatus','=','0')->get();
		//echo Solicitud::where('idProfesor', '=', Auth::user()->id.'')->where('estatus','=','0')->toSql().'  '.Auth::user()->id;
		foreach ($var as $d)
		{
			$documento->idSolicitud=$d->id;			
		}
		$var=Categoria::where('nombre','=','Superación Académica')->get();
		foreach ($var as $d)
		{
			$documento->idCategoria=$d->id;	
		}
		$documento->puntos=60;
		$documento->noConstancia=Input::get('noConstancia');
		$documento->aprobado=false;
		$documento->cotejado=false;
		$documento->imagenConstancia=Str::random(20).Input::file('constanciaFile')->getClientOriginalName();
		$documento->observacion='';
		$documento->save();
		
		$licenciatura=new Licenciatura;
		$licenciatura->id=$documento->id;
		$licenciatura->nombre=Input::get('nombre');
		$licenciatura->fechaExamen=Input::get('fechaExamen');
		
		
		Input::file('constanciaFile')->move('spdImg',$documento->imagenConstancia);
		$licenciatura->save();
		
		
		
		
		
		return Redirect::to('profesor/registrar');
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
}

?>