<?php

class ProfesorController extends BaseController 
{

	public function __construct()
	{
		
		$this->beforeFilter('auth',array('except' =>array('getLogin','postLogin')));
		$this->beforeFilter('esProfesor');
	}

	public function getIndex()
	{
		//return View::make('hello');
		return View::make('profesor.index');
	}

	
	public function getDocumentos()
	{
		return View::make('profesor.documentos');
	}
	
	public function getPerfil()
	{
		$user=Auth::user();
		return View::make('profesor.modificarPerfil')->with('user',$user);
	}
	
	public function getRegistrarDocumento()
	{
		return 'Vista registrar documento';
	}
	
	public function getRegistrarPlaza()
	{
		return View::make('profesor.registrarPlaza');
	}
	
	public function postRegistrarPlaza()
	{
		$rules=array(
		'clave'=>'required|regex:([0-9]{4}\.[a-z0-9A-Z]{2}[0-3][0-9]{3}-[0-9]{3}[0-9]*)|unique:plaza,clavePlaza',
		'tipo' => 'required',
		'noHoras' => 'required|integer'
		);
		$validacion=Validator::make(Input::all(),$rules);
		if($validacion->fails())
		{
			return Redirect::back()->withErrors($validacion)->withInput();
		}
		$plaza= new Plaza;
		$plaza->clavePlaza=Input::get('clave');
		$plaza->tipo=Input::get('tipo');
		$plaza->noHoras=Input::get('noHoras');
		$plaza->idProfesor=Auth::user()->id;
		
		$plaza->save();
		
		return Redirect::to('profesor');
		
		
	}
	
	
	
	
	
	
}