<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Iniciar sesión</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<script src="//code.jquery.com/jquery.js"></script>
    
    <script src="js/bootstrap.min.js"></script>


	<!--<link rel="stylesheet" type="text/css" href="css/estilo.css">-->
</head>
<body>
<!--Se incluye el encabezado de la pagina y la imagen de la pagina -->
<img src="imagenes/bannerIPN.png">

<!--Se hace la parte del menu -->
	<nav class="navbar navbar-default" role="navigation">
  <div class="container-fluid">    <!-- Brand and toggle get grouped for better mobile display -->
    

    <!-- Collect the nav links, forms, and other content for toggling -->    
    <div class="container">
            <br />          
            <br />
            <br />
            <br />
              <div class="row">
                  <div class="col-lg-4"></div>
                   <div class="col-lg-4">

                      <!--<form class="form-signin" role="form">-->
					  {{Form::open()}}
                        <h2 class="form-signin-heading">Iniciar Sesión</h2>
                        <br />
                        <input type="text" name="noEmpleado" value="{{Form::old('id')}}" class="form-control" placeholder="Número de empleado" required autofocus regex="\d\d\d\d\d\d">
                        <br />
                        <input type="password" name="password" class="form-control" placeholder="Contraseña" required>
                        <br />
                        <!--<label class="checkbox">
                          <input type="checkbox" value="remember-me"> Remember me
                        </label>-->
                        <button class="btn btn-lg btn-primary btn-block" type="submit">Iniciar Sesión</button>
						
						{{Form::close()}}
                      <!--</form>-->

                      <br />
                      <br />
                      <div class="alert alert-info">¿Aun no estas registrado? <a href="login/registro">Registrarse</a></div>
                      <br />
                      <div class="alert alert-warning">¿Has olvidado tu contraseña? <a href="#">Recuperar contraseña</a></div>



                   </div> 
                  <div class="col-lg-4"></div>

              </div>            

            </div>


      
    </div>
    

    

  </div><!-- /.container-fluid -->
</nav>		
<!-- -->
    


</body>
</html>