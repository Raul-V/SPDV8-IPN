@extends('layout.registroDocumentos')

@section('titulo')
Registrar Desarrollo Integral
@stop

@section('nombreUsuario')
  {{Auth::user()->nombre}} <!--No cambiar esta seccion -->
@stop

@section('tituloForm') 
Registrar Desarrollo Integral
@stop

@section('formulario')




            <div class="row">
              <div class="col-md-4">
                <div class="form-group">
                  <label class="col-md-3 control-label" for="Semestre">Semestre Escolar</label>  
                  <div class="col-md-9">
                    <input id="Semestre" name="Semestre" placeholder="Ingresa el semestre" class="form-control input-md" type="text" >
                    
                  </div>
                </div>   </div>
              <div class="col-md-4">
                  <div class="form-group">
                  <label class="col-md-3 control-label" for="grupo">Grupo</label>
                  <div class="col-md-9">
                    <input id="grupo" name="grupo" class="form-control input-md" type="text" placeholder="ej: 2CV4">
                  </div>
                </div>

              </div>
              <div class="col-md-4"> 
                <div class="form-group">
                  <label class="col-md-3 control-label" for="nivel">Nivel</label>
                  <div class="col-md-9">
                    <input id="nivel" name="nivel" class="form-control input-md" type="text"  placeholder="nivel">
                  </div>
                </div>


                 </div>
            </div>




            <br /><br />


          


            <div class="row">
              <div class="col-md-2"> </div>
              <div class="col-md-8">


              <div class="form-group">
                  <label class="col-md-3 control-label" for="NohorasSem">No horas sem-semestre</label>
                  <div class="col-md-9">
                    <input id="NohorasSem" name="NohorasSem" class="form-control input-md" type="text" placeholder="ej:50">
                  </div>
                </div>


              </div>
              <div class="col-md-2"> </div>
            </div>




            <br /><br />



            <div class="row">
              <div class="row">
                <div class="col-md-5 col-md-offset-5">
                  <h3>Constancia</h3>
                </div>
              </div>


            <br /><br />
              <div class="col-md-4">
                  <div class="form-group">
                  <label class="col-md-3 control-label" for="año">No.</label>  
                  <div class="col-md-9">
                    <input id="numero" name="numero" placeholder="número" class="form-control input-md" type="text" >                    
                  </div>
                </div> 

               </div>

              <div class="col-md-4"> 

                <div class="form-group">
                  <label class="col-md-3 control-label" for="fecha">Fecha</label>  
                  <div class="col-md-9">
                    <input id="fecha" name="fecha" class="form-control input-md" type="date">                    
                  </div>
                </div> 


              </div>
              
              <div class="col-md-4">

                <div class="form-group">
                  <label class="col-md-3 control-label" for="registro">Registro</label>  
                  <div class="col-md-9">
                    <input id="registro" name="registro" class="form-control input-md" type="text" placeholder="registro de tu constancia">                    
                  </div>
                </div> 

              </div>
              
            </div>



            <br /><br />

            <br /><br />

<div class="row">
  <div class="col-md-4"></div>
  <div class="col-md-4">
    <div class="form-group">
                  <label class="col-md-3 control-label" for="constancia">Documento</label>
                  <div class="col-md-4">
                    <input id="constancia" name="constancia"  type="file">
                  </div>
                </div>
      </div>
  <div class="col-md-4"></div>
</div>

         
 <br /><br />
  <br />

            <div class="row">
              <div class="col-md-2"> </div>
              <div class="col-md-8">


                <div class="form-group">                

                  <label class="col-md-4 control-label" for="registrar"></label>
                  <div class="col-md-8">
                    <button id="registrar" name="registrar" class="btn btn-primary">Registrar</button>
                    <button id="cancelar" name="cancelar" class="btn btn-danger">Cancelar</button>
                  </div>

                </div>  


              </div>
              <div class="col-md-2"> </div>
            </div>


@stop