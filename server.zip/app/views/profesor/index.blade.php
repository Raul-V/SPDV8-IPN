<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Bienvenido {{Auth::user()->nombre}}</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
	{{HTML::style('css/bootstrap.min.css')}}
    <!--<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">-->
	<script src="//code.jquery.com/jquery.js"></script>
    
    <script src="js/bootstrap.min.js"></script>


	<!--<link rel="stylesheet" type="text/css" href="css/estilo.css">-->
</head>
<body>
<!--Se incluye el encabezado de la pagina y la imagen de la pagina -->
<!--<img src="imagenes/bannerIPN.png">-->
{{HTML::image('imagenes/bannerIPN.png')}}
<!--Se hace la parte del menu -->
	<nav class="navbar navbar-default" role="navigation">
  <div class="container-fluid">    <!-- Brand and toggle get grouped for better mobile display -->
  





    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      
      <ul class="nav navbar-nav navbar-right">
       <li><a href="#">Ayuda</a></li>
       <li><a href="../logout">Cerrar Sesión</a></li>
       <p class="navbar-text navbar-right">Mi nombre es:<a href="#" class="bg-success"> {{Auth::user()->nombre}} </a></p>
      </ul>
    </div>

    </div><!-- /.container-fluid -->
</nav>    
<!-- -->
    <br />
    <br />










    <!-- Collect the nav links, forms, and other content for toggling -->    
    <div class="container">
      

        <div class="row">

          <div class="col-sm-6 col-md-3">
            <div class="thumbnail">
              <a href="{{ action('ProfesorController@getPerfil') }}">{{HTML::image('imagenes/modificarPerfil.png')}}</a>
              <div class="caption">
                <h3>Modificar perfil</h3>                
              </div>
            </div>
          </div>

          <div class="col-sm-6 col-md-3">
            <div class="thumbnail">
              <a href="{{action('ProfesorController@getDocumentos')}}">{{HTML::image('imagenes/misDocumentos.png')}}</a>
              <div class="caption">
                <h3>Mis documentos</h3>                
              </div>
            </div>
          </div>


          <div class="col-sm-6 col-md-3">
            <div class="thumbnail">
              <a href="{{action('Profesor_RegistrarController@getIndex')}}">{{HTML::image('imagenes/registrarDocumento.png')}}</a>
              <div class="caption">
                <h3>Registrar Documento</h3>                
              </div>
            </div>
          </div>


		  
		  <div class="col-sm-6 col-md-3">
            <div class="thumbnail">
              <a href="{{ action('ProfesorController@getRegistrarPlaza') }}">{{HTML::image('imagenes/registrarPlaza.png')}}</a>
              <div class="caption">
                <h3>Registrar Plaza</h3>                
              </div>
            </div>
          </div>


        </div>



    </div>
    

    

  

    


</body>
</html>
