@extends('layout.registroDocumentos')

@section('titulo')
	Registrar Programa.
@stop

@section('nombreUsuario')
	{{Auth::user()->nombre}} <!--No cambiar esta seccion -->
@stop

@section('tituloForm')
	Registrar Programa
@stop

@section('formulario')
	
	         <br /><br />
            
            <div class="row">
                <div class="col-md-5 col-md-offset-5">
                  <h3>Datos Generales</h3>
                </div>
              </div>

              <br /><br />

            <div class="row">
              <div class="col-md-2"> </div>
              <div class="col-md-8">


                <div class="form-group">
                  <label class="col-md-3 control-label" for="avance">Dependencia Coordinadora</label>
                  <div class="col-md-9">
                    <select id="avance" name="tipoDependencia" class="form-control">
                      <option value="1">Direccion General</option>
                      <option value="2">Secretaria Academica</option>
                      <option value="3">Secretaria de Investigacion y Posgrado</option>  
                      <option value="4">Secretaria de Extension e Integracion Social</option>                                       
                      <option value="5">Secretaria de Servicios Educativos</option>
                      <option value="6">Secretaria de Gestion Estrategica</option>
                      <option value="7">Secretaria de Administracion</option>
                      <option value="8">Patronato de Obras e Instalaciones del IPN</option>
                      <option value="9">Coordinación General de Servicios Informaticos</option>
                    </select>
                  </div>
                </div> 


              </div>
              <div class="col-md-2"> </div>
            </div>




            <br /><br />





            <div class="row">
              <div class="col-md-2"> </div>
              <div class="col-md-8">


                <div class="form-group">
                  <label class="col-md-3 control-label" for="avance">Nivel</label>
                  <div class="col-md-9">
                    <select id="avance" name="tipoNivel" class="form-control">
                      <option value="1">Nivel Superior</option>
                      <option value="2">Nivel Medio Superior</option>                      
                    </select>
                  </div>
                </div> 


              </div>
              <div class="col-md-2"> </div>
            </div>




            <br /><br />




            <div class="row">
              <div class="row">
                <div class="col-md-5 col-md-offset-5">
                  <h3>Duración</h3>
                </div>
              </div>
              <div class="col-md-2"> </div>

              <div class="col-md-4"> 

                <div class="form-group">
                  <label class="col-md-3 control-label" for="claveRegistro">Inicio</label>  
                  <div class="col-md-9">
                    <input id="textinput" name="claveRegistro" placeholder="Ingresa la fecha de inicio" class="form-control input-md" type="date">                    
                  </div>
                </div> 


              </div>
              
              <div class="col-md-4">

                <div class="form-group">
                  <label class="col-md-3 control-label" for="claveRegistro">Fin</label>  
                  <div class="col-md-9">
                    <input id="textinput" name="claveRegistro" placeholder="Ingresa la fecha de fin" class="form-control input-md" type="date">                    
                  </div>
                </div> 

              </div>

              <div class="col-md-2"> </div>
              
            </div>




            <br />
            <br />


            <div class="row">
              <div class="row">
                <div class="col-md-5 col-md-offset-5">
                  <h3>Constancia</h3>
                </div>
              </div>
              <div class="col-md-2"> </div>

              <div class="col-md-4"> 

                <div class="form-group">
                  <label class="col-md-3 control-label" for="claveRegistro">Número</label>  
                  <div class="col-md-9">
                    <input id="textinput" name="claveRegistro" placeholder="Ingresa el número de constancia" class="form-control input-md" type="text">                    
                  </div>
                </div> 


              </div>
              
              <div class="col-md-4">

                <div class="form-group">
                  <label class="col-md-3 control-label" for="constancia">Constancia de validación</label>
                  <div class="col-md-9">
                    <input id="constancia" name="constancia" class="input-file" type="file">
                  </div>
                </div>

              </div>

              <div class="col-md-2"> </div>
              
            </div>






            <br /> 
            <br />


            <div class="row">
              <div class="row">
                <div class="col-md-5 col-md-offset-5">
                  <h3>Mas información</h3>
                </div>
              </div>
              <div class="col-md-2"> </div>

              <div class="col-md-4"> 

                <div class="form-group">
                  <label class="col-md-3 control-label" for="avance">Nivel de Participación</label>
                  <div class="col-md-9">
                    <select id="avance" name="tipoParticipacion" class="form-control">
                      <option value="1">Coordinador</option>
                      <option value="2">Analista</option>                      
                    </select>
                  </div>
                </div>


              </div>
              
              <div class="col-md-4">

                

                <div class="form-group">
                  <label class="col-md-3 control-label" for="avance">Tipo de programa o proyecto</label>
                  <div class="col-md-9">
                    <select id="avance" name="tipoPrograma" class="form-control">
                      <option value="1">Programa Institucional</option>
                      <option value="2">Proyecto Institucional</option>
                      <option value="3">Proyecto de dependencia</option>                      
                    </select>
                  </div>
                </div>




              </div>

              <div class="col-md-2"> </div>
              
            </div>

	
	
@stop
 