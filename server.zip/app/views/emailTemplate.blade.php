<h1>Te has registrado en el Sistema de promocion Docente del IPN</h1>
<br />
<p>Has registrado los siguientes datos</p>
<!--@if($nombre)
	{{$nombre}}	
@endif-->

Nombre: {{$nombre}} <br />
Apellido Paterno: {{$apellidoP}} <br />
Apellido Materno: {{$apellidoM}} <br />


