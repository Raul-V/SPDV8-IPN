<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSolicitudTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//
		Schema::create('solicitud', function($table)
		{
			$table->increments('id');
			
			$table->integer('idProfesor');
			
			$table->boolean('aprobado');
			$table->smallInteger('estatus');
			$table->timestamp('fecha');
			$table->timestamps();
		}
		);
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		//
		Schema::drop('solicitud');
		
	}

}
