<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDireccionTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//
		Schema::create('direccion', function($table)
		{
			$table->increments('id');
			
			$table->string('calle');
			$table->string('numero');
			$table->string('colonia');
			$table->string('entidadFederativa');
			$table->string('ciudad');
			$table->string('codigoPostal');

			$table->timestamps();
		}
		);
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		//
		Schema::drop('direccion');
	}

}

