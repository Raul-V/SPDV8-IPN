<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsuarioTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//		
		Schema::create('usuario', function($table)
		{
			$table->integer('id')->primary();			
			$table->integer('idInstitucion')->unsigned();
			$table->integer('idDireccion')->unsigned();
			
			$table->string('nombre');			
			$table->string('apellidoP');
			$table->string('apellidoM');
			$table->string('email')->unique();
			$table->string('password');
			$table->smallInteger('rol');		
			$table->smallInteger('sexo');			
			$table->smallInteger('estadoCivil');			
			$table->string('telefono',50);			
			
			$table->timestamps();			
			
		});
		
		
		
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		//
		Schema::drop('usuario');
	}

}
