-><?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSuperacionAcademicaTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//
		Schema::create('licenciatura', function($table)
		{
			$table->integer('id')->unsigned()->primary();
			
			$table->string('nombre');
			$table->date('fechaExamen');			
		}
		);
		
		Schema::create('diplomado', function($table)
		{
			$table->integer('id')->unsigned()->primary();
			
			$table->string('nombreDiplomado');
			$table->string('nombreInstitucion');			
			$table->integer('noHoras');
			$table->string('nivel');
			$table->date('periodoInicio');
			$table->date('periodoTermino');		
			
		}
		);
		
		Schema::create('idioma',function($table)
		{
			$table->integer('id')->unsigned()->primary();
			
			
			$table->string('nombre');
			$table->boolean('lee');
			$table->boolean('escribe');
			$table->boolean('habla');
			
		}
		);
		
		
		
		Schema::create('cursos_proposito_especifico',function($table)
		{
			$table->integer('id')->unsigned()->primary();
			
			$table->date('periodoInicio');			
			$table->date('periodoTermino');
			$table->integer('horasDuracion');
		}
		);
		
		
		
		Schema::create('estudios_posgrado',function($table)
		{
			$table->integer('id')->unsigned()->primary();
			
			$table->string('tipo');
			$table->date('periodoInicio');			
			$table->date('periodoTermino');
			$table->integer('noCreditos');
		}
		);
		
		
		Schema::create('cursos_seminarios_talleres',function($table)
		{
			$table->integer('id')->unsigned()->primary();
			
			
			$table->string('nombre');			
			$table->date('periodoInicio');			
			$table->date('periodoTermino');
			$table->string('evaluacion');
			$table->integer('horasDuracion');
		}
		);
		
		
		Schema::create('programas_proyectos_areas_centrales',function($table)
		{
			$table->integer('id')->unsigned()->primary();
			
			$table->string('dependenciaCoordinadora');
			$table->string('nivel');
			$table->date('inicio');
			$table->date('termino');
			$table->string('nivelParticipacion');
			$table->string('tipo');
		}
		);
		
		
		Schema::create('comision_evaluacion',function($table)
		{
			$table->integer('id')->unsigned()->primary();
			
			$table->string('nombreComision');
			$table->string('tipoParticipacion');
			$table->date('inicio');
			$table->date('termino');
			$table->string('oficioDesignacion');
		}
		);
		
		
		
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		//
		Schema::drop('licenciatura');
		Schema::drop('diplomado');
		Schema::drop('idioma');
		Schema::drop('cursos_proposito_especifico');
		Schema::drop('estudios_posgrado');
		Schema::drop('cursos_seminarios_talleres');
		Schema::drop('programas_proyectos_areas_centrales');
		Schema::drop('comision_evaluacion');
		
	}

}
