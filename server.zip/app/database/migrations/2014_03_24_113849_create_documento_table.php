<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDocumentoTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		//
		Schema::create('documento',function($table)
		{
			$table->increments('id');
			
			$table->integer('idSolicitud')->unsigned();
			$table->integer('idCategoria')->unsigned();
			//$table->integer('idProfesor');//Relacion sin sentido
			$table->integer('puntos');
			$table->string('noConstancia')->unique();
			$table->boolean('aprobado');
			$table->boolean('cotejado');
			$table->string('imagenConstancia');			
			$table->string('observacion');
			
			$table->timestamps();
			
			
		}
		);
		
		
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		//
		Schema::drop('documento');
	}

}
